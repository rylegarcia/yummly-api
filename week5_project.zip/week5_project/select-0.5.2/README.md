## Select

Select.js is a Javascript and CSS library for creating styleable select elements.  It aims to reproduce the behavior of native controls as much as is possible, while allowing for complete styling with CSS.

### [Demo](http://github.hubspot.com/select/docs/welcome) &nbsp;&nbsp; [Documentation](http://github.hubspot.com/select)
